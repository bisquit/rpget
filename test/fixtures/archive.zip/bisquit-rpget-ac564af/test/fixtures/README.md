sample.dir.zip is zip for

```
sample/
  dir-1/
    dir-2/
      file-3
    file-2
  file-1
```

sample.file.zip is zip for

```
file-1
```
